# MySQL JDBC Users Example

## Files
- `Main.java` — connects to MySQL, runs a SELECT query, and prints each user's ID, username, and email.
- `schema.sql` — creates the database/table and inserts sample records.

## Before running
1. Make sure MySQL Server is running.
2. Run `schema.sql` in MySQL Workbench or another MySQL client.
3. In `Main.java`, replace `your_password` with your MySQL password. If your MySQL username is not `root`, update `USERNAME`.
4. Add the MySQL Connector/J driver (`mysql-connector-j`) to your project's classpath.

## Example compile/run (if the connector JAR is downloaded)
Windows Command Prompt:
```bat
javac -cp ".;mysql-connector-j-<version>.jar" Main.java
java -cp ".;mysql-connector-j-<version>.jar" Main
```

Replace `<version>` with the version of the Connector/J JAR you downloaded.

On macOS/Linux, use `:` instead of `;` in the classpath:
```bash
javac -cp ".:mysql-connector-j-<version>.jar" Main.java
java -cp ".:mysql-connector-j-<version>.jar" Main
```

The code uses try-with-resources, so the connection, statement, and result set are closed automatically.
